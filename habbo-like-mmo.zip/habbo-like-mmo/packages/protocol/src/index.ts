// Tipos base do tempo real
export type Vector2 = { x: number; y: number };

export type ClientToServer =
  | { t: "hello"; name: string; look: string }
  | { t: "enter_room"; roomId: string }
  | { t: "leave_room" }
  | { t: "click_move"; target: Vector2 }
  | { t: "chat"; message: string }
  | { t: "place_furniture"; defId: string; at: Vector2; rot: 0 | 1 | 2 | 3 }
  | { t: "interact"; objectId: string; action: "sit" | "toggle" }
  | { t: "heartbeat" };

export type ServerToClient =
  | { t: "welcome"; youId: string; rooms: RoomSummary[]; credits: number }
  | { t: "room_list"; rooms: RoomSummary[] }
  | { t: "room_joined"; room: RoomStateSnapshot }
  | { t: "room_left" }
  | { t: "entity_joined"; entity: Entity }
  | { t: "entity_left"; id: string }
  | { t: "entity_moved"; id: string; path: Vector2[] }
  | { t: "chat"; fromId: string; message: string }
  | { t: "furniture_placed"; item: FurnitureInstance }
  | { t: "furniture_updated"; item: FurnitureInstance }
  | { t: "balance_update"; credits: number }
  | { t: "tick"; diffs: StateDiff[] };

export type RoomSummary = { id: string; name: string; users: number; tags?: string[] };

export type Entity = {
  id: string;
  name: string;
  look: string;
  pos: Vector2;
  facing: 0 | 1 | 2 | 3;
  state: "idle" | "walk" | "sit" | "lay";
};

export type FurnitureInstance = {
  id: string;
  defId: string;
  at: Vector2;
  rot: 0 | 1 | 2 | 3;
  blocks: Vector2[];
  kind: "chair" | "table" | "lamp" | "door";
  meta?: Record<string, any>;
};

export type RoomStateSnapshot = {
  id: string;
  name: string;
  size: { w: number; h: number };
  tiles: number[][];
  furniture: FurnitureInstance[];
  entities: Entity[];
};

export type StateDiff =
  | { k: "entity"; id: string; patch: Partial<Entity> }
  | { k: "furniture"; id: string; patch: Partial<FurnitureInstance> }
  | { k: "add_entity"; entity: Entity }
  | { k: "remove_entity"; id: string };
