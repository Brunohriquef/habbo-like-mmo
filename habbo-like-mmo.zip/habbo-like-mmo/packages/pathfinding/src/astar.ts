export function findPath(
  grid: number[][],
  start: { x: number; y: number },
  goal: { x: number; y: number },
  isBlocked?: (x: number, y: number) => boolean
) {
  const W = grid[0].length,
    H = grid.length;
  const key = (x: number, y: number) => `${x},${y}`;
  const open: [number, number, number, number, number, string?][] = [];
  const g = new Map<string, number>();
  const came = new Map<string, string>();
  const h = (x: number, y: number) => Math.abs(x - goal.x) + Math.abs(y - goal.y);

  const startK = key(start.x, start.y);
  g.set(startK, 0);
  open.push([h(start.x, start.y), 0, start.x, start.y, h(start.x, start.y), undefined]);
  const dirs = [
    [1, 0],
    [-1, 0],
    [0, 1],
    [0, -1],
  ];
  while (open.length) {
    open.sort((a, b) => a[0] - b[0]);
    const [_, gx, x, y, __, parent] = open.shift()!;
    const k = key(x, y);
    if (parent) came.set(k, parent);
    if (x === goal.x && y === goal.y) {
      const path = [{ x, y }];
      let cur = k;
      while (came.has(cur)) {
        const p = came.get(cur)!;
        const [px, py] = p.split(",").map(Number);
        path.push({ x: px, y: py });
        cur = p;
      }
      return path.reverse();
    }
    for (const [dx, dy] of dirs) {
      const nx = x + dx,
        ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      if (grid[ny][nx] > 0) continue;
      if (isBlocked?.(nx, ny)) continue;
      const nk = key(nx, ny);
      const tentative = gx + 1;
      if (tentative < (g.get(nk) ?? Infinity)) {
        g.set(nk, tentative);
        open.push([tentative + h(nx, ny), tentative, nx, ny, h(nx, ny), k]);
      }
    }
  }
  return [];
}
