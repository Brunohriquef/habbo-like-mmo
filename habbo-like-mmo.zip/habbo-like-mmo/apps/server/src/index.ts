import http from "http";
import { WebSocketServer } from "ws";
import {
  ClientToServer,
  ServerToClient,
  RoomStateSnapshot,
  Entity,
  RoomSummary,
} from "@protocol";
import { findPath } from "@pathfinding";

const server = http.createServer();
const wss = new WebSocketServer({ server });
server.listen(8787, () => console.log("WS on :8787"));

type Client = { id: string; ws: any; roomId?: string; entity?: Entity };

const clients = new Map<string, Client>();
const rooms = new Map<string, RoomStateSnapshot>();
rooms.set("plaza", {
  id: "plaza",
  name: "Praça",
  size: { w: 32, h: 24 },
  tiles: Array.from({ length: 24 }, () => Array(32).fill(0)),
  furniture: [],
  entities: [],
});
function uid() {
  return Math.random().toString(36).slice(2, 9);
}
function broadcast(roomId: string, msg: ServerToClient) {
  for (const c of clients.values()) {
    if (c.roomId === roomId) c.ws.send(JSON.stringify(msg));
  }
}
function roomList(): RoomSummary[] {
  return Array.from(rooms.values()).map((r) => ({ id: r.id, name: r.name, users: r.entities.length }));
}
wss.on("connection", (ws) => {
  const id = uid();
  const c: Client = { id, ws };
  clients.set(id, c);
  const welcome: ServerToClient = { t: "welcome", youId: id, rooms: roomList(), credits: 50 };
  ws.send(JSON.stringify(welcome));
  ws.on("message", (buf) => {
    let msg: ClientToServer;
    try {
      msg = JSON.parse(String(buf));
    } catch {
      return;
    }
    if (msg.t === "hello") {
      c.entity = {
        id,
        name: msg.name || `Habbito_${id}`,
        look: msg.look || "body:tan;hair:short:#333;top:t:#66C",
        pos: { x: 5, y: 5 },
        facing: 1,
        state: "idle",
      };
      return;
    }
    if (msg.t === "enter_room" && rooms.has(msg.roomId) && c.entity) {
      if (c.roomId) {
        const prev = rooms.get(c.roomId)!;
        prev.entities = prev.entities.filter((e) => e.id !== c.id);
        broadcast(c.roomId, { t: "entity_left", id: c.id });
        c.roomId = undefined;
        ws.send(JSON.stringify({ t: "room_left" } as ServerToClient));
      }
      const room = rooms.get(msg.roomId)!;
      room.entities.push(c.entity);
      c.roomId = room.id;
      ws.send(JSON.stringify({ t: "room_joined", room }));
      broadcast(room.id, { t: "entity_joined", entity: c.entity });
      const list = { t: "room_list", rooms: roomList() } as ServerToClient;
      for (const cl of clients.values()) cl.ws.send(JSON.stringify(list));
      return;
    }
    if (msg.t === "leave_room" && c.roomId) {
      const room = rooms.get(c.roomId)!;
      room.entities = room.entities.filter((e) => e.id !== c.id);
      broadcast(c.roomId, { t: "entity_left", id: c.id });
      c.roomId = undefined;
      ws.send(JSON.stringify({ t: "room_left" }));
      return;
    }
    if (msg.t === "click_move" && c.roomId && c.entity) {
      const room = rooms.get(c.roomId)!;
      const path = findPath(
        room.tiles,
        c.entity.pos,
        msg.target,
        (x, y) => room.furniture.some((f) => f.blocks.some((b) => b.x === x && b.y === y))
      );
      if (path.length) {
        broadcast(c.roomId, { t: "entity_moved", id: c.id, path });
        c.entity.pos = path[path.length - 1];
        c.entity.state = "walk";
      }
      return;
    }
    if (msg.t === "chat" && c.roomId && c.entity && msg.message.trim()) {
      broadcast(c.roomId, { t: "chat", fromId: c.id, message: msg.message.slice(0, 240) });
      return;
    }
    if (msg.t === "place_furniture" && c.roomId) {
      const room = rooms.get(c.roomId)!;
      const idF = uid();
      const blocks = [{ x: msg.at.x, y: msg.at.y }];
      const kind = msg.defId.includes("chair")
        ? "chair"
        : msg.defId.includes("lamp")
        ? "lamp"
        : "table";
      const item = {
        id: idF,
        defId: msg.defId,
        at: msg.at,
        rot: msg.rot,
        blocks,
        kind,
        meta: {} as any,
      };
      room.furniture.push(item);
      broadcast(room.id, { t: "furniture_placed", item });
      return;
    }
    if (msg.t === "interact" && c.roomId) {
      const room = rooms.get(c.roomId)!;
      const it = room.furniture.find((f) => f.id === msg.objectId);
      if (!it) return;
      if (it.kind === "lamp") {
        it.meta.on = !it.meta.on;
        broadcast(room.id, { t: "furniture_updated", item: it });
      }
      if (it.kind === "chair" && c.entity) {
        c.entity.state = "sit";
        broadcast(room.id, { t: "entity_moved", id: c.id, path: [it.at] });
      }
      return;
    }
  });
  ws.on("close", () => {
    if (c.roomId) {
      const room = rooms.get(c.roomId)!;
      room.entities = room.entities.filter((e) => e.id !== c.id);
      broadcast(c.roomId, { t: "entity_left", id: c.id });
    }
    clients.delete(id);
  });
});
