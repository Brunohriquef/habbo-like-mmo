import { create } from "zustand";
import type { RoomStateSnapshot, Entity, FurnitureInstance, RoomSummary } from "@protocol";

type ChatMsg = { fromId: string; message: string; ts: number };

type State = {
  youId?: string;
  credits: number;
  rooms: RoomSummary[];
  room?: RoomStateSnapshot;
  entities: Record<string, Entity>;
  chat: ChatMsg[];
  set: (p: Partial<State>) => void;
};

export const useGame = create<State>((set) => ({
  credits: 0,
  rooms: [],
  entities: {},
  chat: [],
  set: (p) => set(p),
}));
